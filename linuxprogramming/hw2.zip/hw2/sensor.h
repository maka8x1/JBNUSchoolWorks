typedef struct {
        int id;
        char name[100];
        char status[100];
} sensordata;

