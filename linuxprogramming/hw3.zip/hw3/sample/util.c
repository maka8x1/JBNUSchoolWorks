#include <stdio.h>

void banner(const char* msg) {
    printf("=== %s ===\n", msg);
}
