#ifndef UTIL_H
#define UTIL_H
void banner(const char* msg);
#endif
